import React from 'react';
import { View, Text, Button } from 'react-native';
import { useSession } from '@/lib/session';

export function SettingsScreen() {
  const { logout } = useSession();
  return (
    <View style={{ flex:1, justifyContent:'center', alignItems:'center', gap:12 }}>
      <Text>Настройки</Text>
      <Button title="Выйти" onPress={logout} />
    </View>
  );
}
