import React, { useState } from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';
import { useSession } from '@/lib/session';
import { Auth } from '@/lib/api';

export function LoginScreen() {
  const { setToken } = useSession();
  const [email, setEmail] = useState('admin@mobilive.ge');
  const [password, setPassword] = useState('Admin123!');
  const [loading, setLoading] = useState(false);

  const onLogin = async () => {
    try {
      setLoading(true);
      const r = await Auth.login(email, password);
      if (r?.token) await setToken(r.token);
      else Alert.alert('Ошибка', 'Неверный ответ сервера');
    } catch (e:any) {
      Alert.alert('Ошибка входа', e?.message || 'Неизвестная ошибка');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ padding:16, gap:12 }}>
      <Text>Email</Text>
      <TextInput autoCapitalize="none" keyboardType="email-address"
        value={email} onChangeText={setEmail}
        style={{ borderWidth:1, borderRadius:8, padding:10 }} />
      <Text>Пароль</Text>
      <TextInput secureTextEntry value={password} onChangeText={setPassword}
        style={{ borderWidth:1, borderRadius:8, padding:10 }} />
      <Button title={loading ? 'Вход...' : 'Войти'} onPress={onLogin} />
    </View>
  );
}
