import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Button } from 'react-native';

const keys = ['1','2','3','4','5','6','7','8','9','*','0','#'];

export function DialpadScreen() {
  const [number, setNumber] = useState('');
  const press = (k:string) => setNumber(n => (n + k).slice(0, 32));
  const clear = () => setNumber('');

  return (
    <View style={s.wrap}>
      <Text style={s.number}>{number || 'Введите номер'}</Text>
      <View style={s.grid}>
        {keys.map(k => (
          <TouchableOpacity key={k} style={s.key} onPress={() => press(k)}>
            <Text style={s.keyText}>{k}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <View style={{ flexDirection:'row', gap:12, marginTop:16 }}>
        <Button title="Позвонить" onPress={() => { /* TODO: integrate call API */ }} />
        <Button title="Стереть" onPress={clear} />
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  wrap: { flex:1, padding:16, alignItems:'center' },
  number: { fontSize:24, marginVertical:12 },
  grid: { flexDirection:'row', flexWrap:'wrap', width:300, justifyContent:'center' },
  key: { width:90, height:60, borderWidth:1, borderRadius:12, margin:5, alignItems:'center', justifyContent:'center' },
  keyText: { fontSize:22 }
});
