import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { DialpadScreen } from '@/screens/DialpadScreen';
import { ContactsScreen } from '@/screens/ContactsScreen';
import { RecentsScreen } from '@/screens/RecentsScreen';
import { MessagesScreen } from '@/screens/MessagesScreen';
import { SettingsScreen } from '@/screens/SettingsScreen';

export type TabsParamList = {
  Contacts: undefined;
  Recents: undefined;
  Dialpad: undefined;
  Messages: undefined;
  Settings: undefined;
};

const Tab = createBottomTabNavigator<TabsParamList>();

export function MainTabs() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Contacts" component={ContactsScreen} options={{ title: 'Контакты' }} />
      <Tab.Screen name="Recents" component={RecentsScreen} options={{ title: 'Журнал' }} />
      <Tab.Screen name="Dialpad" component={DialpadScreen} options={{ title: 'Набор' }} />
      <Tab.Screen name="Messages" component={MessagesScreen} options={{ title: 'Сообщения' }} />
      <Tab.Screen name="Settings" component={SettingsScreen} options={{ title: 'Настройки' }} />
    </Tab.Navigator>
  );
}
