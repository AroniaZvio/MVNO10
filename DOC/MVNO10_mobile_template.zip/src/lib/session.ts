import { create } from 'zustand';
import * as SecureStore from 'expo-secure-store';
import { Auth } from './api';

export type User = { id:number; email:string; firstName?:string; lastName?:string };

type S = {
  ready: boolean;
  user: User | null;
  token: string | null;
  load: () => Promise<void>;
  setToken: (t:string) => Promise<void>;
  logout: () => Promise<void>;
};

export const useSession = create<S>((set, get) => ({
  ready: false,
  user: null,
  token: null,
  load: async () => {
    const t = await SecureStore.getItemAsync('token');
    if (!t) { set({ ready:true, user:null, token:null }); return; }
    try {
      const me = await Auth.me(t);
      if (me && me.id) set({ user: me, token: t, ready: true });
      else set({ ready: true, user: null, token: null });
    } catch {
      set({ ready: true, user: null, token: null });
    }
  },
  setToken: async (t: string) => {
    await SecureStore.setItemAsync('token', t);
    set({ token: t });
    const me = await Auth.me(t);
    if (me && me.id) set({ user: me });
  },
  logout: async () => {
    await SecureStore.deleteItemAsync('token');
    set({ user: null, token: null });
  }
}));
