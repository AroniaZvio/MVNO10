import Constants from 'expo-constants';

const API_URL: string = (Constants?.expoConfig?.extra as any)?.API_URL || 'http://192.168.0.83:4000';

async function req(path: string, options: RequestInit = {}) {
  const res = await fetch(`${API_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || res.statusText);
  }
  return res.json();
}

export const api = {
  get: (path: string) => req(path),
  post: (path: string, body?: any) => req(path, { method: 'POST', body: JSON.stringify(body) }),
  put: (path: string, body?: any) => req(path, { method: 'PUT', body: JSON.stringify(body) }),
  del: (path: string) => req(path, { method: 'DELETE' })
};

export const Auth = {
  async login(email: string, password: string) {
    return api.post('/api/auth/login', { email, password });
  },
  async me(token?: string) {
    return fetch(`${API_URL}/api/auth/me`, { headers: { Authorization: `Bearer ${token}` } }).then(r => r.json());
  }
};
