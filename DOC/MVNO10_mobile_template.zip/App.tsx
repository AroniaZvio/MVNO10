import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { StatusBar } from 'expo-status-bar';
import { useSession } from '@/lib/session';
import { AuthNavigator } from '@/navigation/AuthNavigator';
import { MainTabs } from '@/navigation/MainTabs';
import { View, ActivityIndicator } from 'react-native';

export default function App() {
  const { ready, user, load } = useSession();
  React.useEffect(() => { load(); }, []);

  if (!ready) {
    return (
      <View style={{ flex:1, justifyContent:'center', alignItems:'center' }}>
        <ActivityIndicator />
      </View>
    );
  }

  return (
    <NavigationContainer>
      {user ? <MainTabs /> : <AuthNavigator />}
      <StatusBar style="auto" />
    </NavigationContainer>
  );
}
