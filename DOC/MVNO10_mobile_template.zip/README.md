# MVNO10 Mobile (Expo, iOS & Android)

Готовый шаблон под ваш проект MVNO10. Работает на Expo (SDK 52), React Navigation и Zustand.

## 1) Установка

```bash
# В Windows: откройте PowerShell
cd D:/APP
# распакуйте архив в папку MVNO10_mobile (или скачайте этот шаблон)
cd MVNO10_mobile
npm i
npx expo-doctor
```

Поставьте Android Studio (SDK 34+) и включите `adb`. Для iOS локальный запуск возможен только на Mac. 
На Windows собирайте iOS через EAS (облако).

## 2) Локальный запуск (LAN, iPhone 12 через Expo Go)
1. Телефон и ПК должны быть в одной сети (у вас: 192.168.0.83).
2. В `app.json` уже указан `extra.API_URL` = `http://192.168.0.83:4000`.
3. Запустите:
```bash
npm run start
```
4. В приложении **Expo Go** на iPhone отсканируйте QR и откройте проект.

## 3) Билды через EAS (iOS и Android)
```bash
npx eas-cli login
eas init    # создаст проект в EAS, вставьте projectId в app.json -> extra.eas.projectId
eas build -p android --profile preview
eas build -p ios --profile preview
```
Подписей нет? EAS спросит и создаст автоматически (рекомендуется).

## 4) Структура
- `App.tsx` — переключает гостя (Auth) и вкладки телефона (MainTabs).
- `src/navigation/*` — стеки и табы.
- `src/screens/*` — экраны (логин, набор номера и т.д.).
- `src/lib/api.ts` — простой клиент к бэкенду.
- `src/lib/session.ts` — Zustand + SecureStore для токена и профиля.

## 5) Подключение к вашему backend
- Логин POST `/api/auth/login` — ожидается `{ token }` в ответе.
- Профиль GET `/api/auth/me` — заголовок `Authorization: Bearer <token>`.

Если бэкенд на `localhost:4000`, с телефона он **недоступен**. Используйте IP: `http://192.168.0.83:4000`.

## 6) Полезные команды
```bash
npm run android        # собрать и запустить на эмуляторе
npm run ios            # требуется macOS + Xcode
npm run build          # EAS билд iOS+Android
```

## 7) Дальше
- Добавить реальный вызов API для звонков/истории.
- Заменить заглушки экранов на ваши данные.
- Настроить диплинки и пуши при необходимости.
